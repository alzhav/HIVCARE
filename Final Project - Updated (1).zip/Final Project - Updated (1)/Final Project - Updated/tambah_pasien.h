// =============== tambah_pasien.h ===============
#ifndef TAMBAH_PASIEN_H
#define TAMBAH_PASIEN_H

#include "struktur_data.h"

void tambah_pasien_baru();

#endif 
