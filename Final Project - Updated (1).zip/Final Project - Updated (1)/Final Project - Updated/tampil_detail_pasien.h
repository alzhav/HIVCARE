
// =============== tampil_detail_pasien.h ===============
#ifndef TAMPIL_DETAIL_PASIEN_H
#define TAMPIL_DETAIL_PASIEN_H

#include "struktur_data.h"
#include "kelola_terapi.h" // Untuk clear_input_buffer dan cari_pasien_by_id
#include <stdio.h>
#include <string.h>

void tampilkan_detail_pasien();

#endif // TAMPIL_DETAIL_PASIEN_H
