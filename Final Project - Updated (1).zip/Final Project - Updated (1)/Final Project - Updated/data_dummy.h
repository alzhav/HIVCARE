#ifndef DATA_DUMMY_H
#define DATA_DUMMY_H

#include "struktur_data.h" // Diperlukan jika ada penggunaan tipe data dari sana

// Fungsi untuk membuat beberapa data pasien dummy
// Berguna untuk testing dan demonstrasi awal
void buat_data_dummy();

#endif // DATA_DUMMY_H
