#ifndef TAMPIL_SEMUA_PASIEN_H 
#define TAMPIL_SEMUA_PASIEN_H

#include "struktur_data.h" 
#include <stdio.h>       

void tampilkan_semua_pasien();

#endif 
